package ibis.ipl.impl.registry.gossip;

import ibis.ipl.impl.IbisIdentifier;
import ibis.util.TypedProperties;

import java.io.DataInputStream;
import java.io.DataOutputStream;

public class ElectionSet {

    public ElectionSet(TypedProperties properties, Registry registry) {
        // TODO Auto-generated constructor stub
    }

    public void writeGossipData(DataOutputStream stream) {
        // TODO Auto-generated method stub
        
    }

    public void readGossipData(DataInputStream stream) {
        // TODO Auto-generated method stub
        
    }

    public IbisIdentifier getElectionResult(long timeoutMillis) {
        // TODO Auto-generated method stub
        return null;
    }

    public IbisIdentifier elect(String electionName) {
        // TODO Auto-generated method stub
        return null;
    }

    public IbisIdentifier elect(String electionName, long timeoutMillis) {
        // TODO Auto-generated method stub
        return null;
    }

}
